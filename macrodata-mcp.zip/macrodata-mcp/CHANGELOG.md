# Changelog

## 0.1.0

- Initial release of MacroData MCP, derived from fred-mcp-server 1.2.0 (AGPL-3.0).
- Tools renamed: `macro_browse`, `macro_search`, `macro_series`.
- Source module renamed `src/fred` -> `src/macro`; server and bin renamed `macrodata-mcp`.
- New README, branding, and a single CI workflow.
