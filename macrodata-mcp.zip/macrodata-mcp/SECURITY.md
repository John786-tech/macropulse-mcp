# Security policy

Please report vulnerabilities through GitHub's private "Report a vulnerability"
feature on this repository rather than a public issue.

Notes for operators:
- Keep `FRED_API_KEY` in environment variables or a secrets manager; never commit it.
- When using the HTTP transport, bind with `HOST=127.0.0.1` unless you add your own
  authentication or network controls in front of it.
- `MCP_MAX_SESSIONS` and `MCP_BODY_LIMIT` bound resource use.
