import { describe, expect, test, jest, beforeEach, afterAll } from '@jest/globals';
import { registerFREDTools } from '../../../src/macro/tools.js';

// Create a mock for console.error to avoid cluttering test output
const originalConsoleError = console.error;
console.error = jest.fn();

// Clean up after tests
afterAll(() => {
  console.error = originalConsoleError;
});

describe('FRED tools module', () => {
  // Create a mock server for testing
  const createMockServer = () => ({
    registerTool: jest.fn()
  });
  
  beforeEach(() => {
    jest.clearAllMocks();
  });
  
  describe('registerFREDTools', () => {
    test('function exists and has correct signature', () => {
      expect(typeof registerFREDTools).toBe('function');
    });
    
    test('registers all three tools with the server', () => {
      const mockServer = createMockServer();
      registerFREDTools(mockServer as any);
      
      // Verify server.registerTool was called three times
      expect(mockServer.registerTool).toHaveBeenCalledTimes(3);
      
      // Get the registered tools
      const toolCalls = mockServer.registerTool.mock.calls;
      const toolNames = toolCalls.map(call => call[0]);
      
      // Verify all three tools are registered
      expect(toolNames).toContain('macro_browse');
      expect(toolNames).toContain('macro_search');
      expect(toolNames).toContain('macro_series');
    });
    
    test('macro_browse tool has correct schema', () => {
      const mockServer = createMockServer();
      registerFREDTools(mockServer as any);
      
      // Find the browse tool registration
      const browseToolCall = mockServer.registerTool.mock.calls.find(call => call[0] === 'macro_browse');
      expect(browseToolCall).toBeDefined();
      
      // Verify schema has expected fields
      const schema = browseToolCall![1].inputSchema;
      expect(schema).toHaveProperty('browse_type');
      expect(schema).toHaveProperty('category_id');
      expect(schema).toHaveProperty('release_id');
      expect(schema).toHaveProperty('limit');
      expect(schema).toHaveProperty('offset');
      expect(schema).toHaveProperty('order_by');
      expect(schema).toHaveProperty('sort_order');
    });
    
    test('macro_search tool has correct schema', () => {
      const mockServer = createMockServer();
      registerFREDTools(mockServer as any);
      
      // Find the search tool registration
      const searchToolCall = mockServer.registerTool.mock.calls.find(call => call[0] === 'macro_search');
      expect(searchToolCall).toBeDefined();
      
      // Verify schema has expected fields
      const schema = searchToolCall![1].inputSchema;
      expect(schema).toHaveProperty('search_text');
      expect(schema).toHaveProperty('search_type');
      expect(schema).toHaveProperty('tag_names');
      expect(schema).toHaveProperty('limit');
      expect(schema).toHaveProperty('offset');
    });
    
    test('macro_series tool has correct schema', () => {
      const mockServer = createMockServer();
      registerFREDTools(mockServer as any);
      
      // Find the get_series tool registration
      const getSeriesToolCall = mockServer.registerTool.mock.calls.find(call => call[0] === 'macro_series');
      expect(getSeriesToolCall).toBeDefined();
      
      // Verify schema has expected fields
      const schema = getSeriesToolCall![1].inputSchema;
      expect(schema).toHaveProperty('series_id');
      expect(schema).toHaveProperty('observation_start');
      expect(schema).toHaveProperty('observation_end');
      expect(schema).toHaveProperty('limit');
      expect(schema).toHaveProperty('units');
      expect(schema).toHaveProperty('frequency');
    });
    
    test('all tool handlers are functions', () => {
      const mockServer = createMockServer();
      registerFREDTools(mockServer as any);
      
      // Verify all handlers are functions
      mockServer.registerTool.mock.calls.forEach(call => {
        const handler = call[2];
        expect(typeof handler).toBe('function');
      });
    });
  });
});