# Notice and attribution

MacroData MCP is derived from **fred-mcp-server** by Stefano Amorelli
(https://github.com/stefanoamorelli/fred-mcp-server), licensed under the
GNU Affero General Public License v3.0.

This project is distributed under the same license (see `LICENSE`). Changes made
relative to the original include renamed tools and package, a reorganised
`src/macro` module, new documentation, a new CI workflow and new branding.
Original copyright notices are preserved; see `AUTHORS`.

Because the AGPL-3.0 applies, anyone who runs a modified version of this software
as a network service must offer the corresponding source code to its users.

"FRED" is a registered trademark of the Federal Reserve Bank of St. Louis. This
project is not affiliated with, sponsored by, or endorsed by the Federal Reserve
or the Federal Reserve Bank of St. Louis.
