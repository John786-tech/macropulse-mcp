<p align="center"><img src="assets/logo.svg" alt="MacroData MCP" width="480"></p>

# MacroData MCP

Give your AI assistant direct access to **800,000+ macroeconomic time series** from the Federal Reserve Economic Data (FRED) API, through the [Model Context Protocol](https://modelcontextprotocol.io).

> **Not affiliated with the Federal Reserve.** "FRED" is a registered trademark of the Federal Reserve Bank of St. Louis, used descriptively only.
>
> **Derived work.** MacroData MCP is a modified version of [fred-mcp-server](https://github.com/stefanoamorelli/fred-mcp-server) by Stefano Amorelli, used under the AGPL-3.0. See [NOTICE.md](NOTICE.md).

## What you can ask

- "What is the latest US unemployment rate, and how does it compare to a year ago?"
- "Find monthly, seasonally adjusted series about housing starts."
- "Show me the release schedule categories under Prices."

## Tools

| Tool | Purpose | Key inputs |
| --- | --- | --- |
| `macro_browse` | Walk the catalog: categories, releases, sources, and the series inside them | `browse_type`, `category_id`, `release_id` |
| `macro_search` | Find series by text, series ID, or tags | `search_text`, `tag_names`, `filter_variable` |
| `macro_series` | Pull observations with transforms and re-aggregation | `series_id`, `units`, `frequency`, dates |

Common `units` transforms: `lin` (levels), `pch` (% change), `pc1` (% change vs. year ago), `pca` (compounded annual rate), `log`.

## Quick start

You need a free [FRED API key](https://fred.stlouisfed.org/docs/api/api_key.html).

```bash
git clone <this-repo-url> macrodata-mcp
cd macrodata-mcp
pnpm install
pnpm build
```

### Claude Desktop

```json
{
  "mcpServers": {
    "macrodata": {
      "command": "node",
      "args": ["/absolute/path/to/macrodata-mcp/build/index.js"],
      "env": { "FRED_API_KEY": "your-key" }
    }
  }
}
```

### Docker

```bash
docker build -t macrodata-mcp .
docker run -i --rm -e FRED_API_KEY=your-key macrodata-mcp
```

### HTTP transport

```bash
FRED_API_KEY=your-key node build/index.js --http     # http://localhost:3000/mcp
PORT=8080 HOST=127.0.0.1 TRANSPORT=http node build/index.js
```

`GET /healthz` returns session count, request/cache stats and uptime.

## Configuration

| Variable | Default | Meaning |
| --- | --- | --- |
| `FRED_API_KEY` | required | Your FRED API key |
| `FRED_API_TIMEOUT_MS` | `30000` | Per-request timeout |
| `FRED_API_MAX_RETRIES` | `3` | Retries on 429/5xx/network errors |
| `FRED_API_RETRY_BASE_DELAY_MS` | `500` | Backoff base delay |
| `FRED_RATE_LIMIT_PER_MINUTE` | `120` | Client-side rate limit |
| `FRED_CACHE_TTL_MS` | `60000` | Response cache TTL (`0` disables) |
| `FRED_CACHE_MAX_ENTRIES` | `500` | LRU cache size |
| `TRANSPORT` | `stdio` | `stdio` or `http` |
| `HOST` / `PORT` | all interfaces / `3000` | HTTP bind settings |
| `MCP_MAX_SESSIONS` | `100` | Concurrent session cap |
| `MCP_SESSION_TTL_MS` | `1800000` | Idle session expiry |
| `MCP_BODY_LIMIT` | `1mb` | Max JSON body |
| `LOG_LEVEL` | `info` | `error`, `warn`, `info`, `debug` (stderr) |

## Project layout

```
src/
  index.ts          entry point, stdio + HTTP transports
  macro/            the three tools and their handlers
  common/           FRED client, retry, cache, rate limiter, config, logging
  http/             session manager for the HTTP transport
test/               unit, integration and conformance tests
```

## Development

```bash
pnpm build      # compile TypeScript
pnpm lint       # type-check only
pnpm test       # run the Jest suite
```

## License

GNU Affero General Public License v3.0. See [LICENSE](LICENSE) and [NOTICE.md](NOTICE.md). If you run a modified version as a network service, you must make the corresponding source available to its users.
